<?php
############################################################
# This file is part of Web-WoW CMS V2 @ web-wow.net
# Do not redistribute it without premission from AXE.
# Copyright (c) AXE, zg_20102 at hotmail dot com
#
############################################################
if (!defined('PATHROOT')) define('PATHROOT', '../');
define('WEBWOW', 'www.web-wow.net');
