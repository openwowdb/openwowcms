INSERT INTO `wwc2_links` VALUES ('451', 'Home', './index.php', '', 'leftmenu', '1', '0');
INSERT INTO `wwc2_links` VALUES ('452', 'Userpanel', './?page=userpanel', 'User Control Panel', 'leftmenu', '2', '2');
INSERT INTO `wwc2_links` VALUES ('453', 'Test Link', './index.php', '', 'leftmenubottom', '0', '0');
INSERT INTO `wwc2_links` VALUES ('454', 'Admin link', './test', 'test', 'leftmenubottom', '1', '4');
