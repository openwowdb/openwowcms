x-y-z-boxed.php

y -> order, ASCENDING (just between plugins, numbers)
z -> 0 - before content, 1 - after content
x -> in what part it will be shown, template name (example: body1, header, footer)
boxed-> if there is template wrapper around that plugin (0 = no, 1 = yes)



/data/ - folder for plugin data

Can be placed on any element except wrappers, not suggested to body4,5,6.