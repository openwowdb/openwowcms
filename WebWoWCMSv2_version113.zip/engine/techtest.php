test[|]
test2[|]test2samelineastest2
test4newline
