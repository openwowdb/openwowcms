Please do not change module names, it may lead to error. 

Filename format: <unique_designation>-<module_name>.php